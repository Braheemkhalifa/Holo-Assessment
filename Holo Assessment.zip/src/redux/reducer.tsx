import { InitState } from 'types/InitReducer';

export const UpdateReduxData = (key: string, value) => ({
  type: 'SET_VALUE',
  payload: { key, value }
});

const initState: InitState = {
  searchType: 'users',
  searchValue: null,
  dataError: null,
  dataLoaded: true,
  data: []
};

const appReducer = (state = initState, action) => {
  switch (action.type) {
    case 'SET_VALUE':
      return { ...state, [action.payload.key]: action.payload.value };

    default:
      return state;
  }
};

export default appReducer;
