import axios from 'axios';

//get all orders
export const getOrders = (searchType, searchWord) =>
  axios.get(`https://api.github.com/search/${searchType}?q=${searchWord}`);
