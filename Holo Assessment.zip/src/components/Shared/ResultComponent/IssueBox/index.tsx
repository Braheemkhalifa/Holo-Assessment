import Link from 'next/link';
import dateFormat from 'dateformat';
import UserBox from '../UserBox';

type Props = {
  repoUrl: string;
  issueUrl: string;
  issueTitle: string;
  issueAuthor?: string;
  issueAuthorAvatar?: string;
  issueAuthorUrl?: string;
  issueState: string;
  issueBody: string;
  issueCreatedDate: string;
};
const IssueBox = ({
  repoUrl,
  issueUrl,
  issueTitle,
  issueAuthor,
  issueAuthorAvatar,
  issueAuthorUrl,
  issueState,
  issueBody,
  issueCreatedDate
}: Props) => {
  return (
    <div className="py-3 h-full">
      <div className="flex flex-col gap-3 justify-between h-full ">
        <Link href={issueUrl} passHref>
          <a>
            <h3 className="font-bold text-lg capitalize hover:text-blue-700 w-full overflow-hidden">
              {issueTitle}
            </h3>
          </a>
        </Link>
        <p className="overflow-hidden truncate block ">{issueBody}</p>
        <div className="flex gap-3 justify-between">
          <p className="w-2/3">
            <span className="block font-bold">Created Date : </span>
            {dateFormat(issueCreatedDate, 'mediumDate')}
          </p>
          <p className="w-1/3">
            <span className="block font-bold">State : </span> {issueState}
          </p>
        </div>

        <UserBox
          showBorder
          userName={issueAuthor}
          userAvatar={issueAuthorAvatar}
          userUrl={issueAuthorUrl}
        />

        <Link href={repoUrl} passHref>
          <a target="_blank">
            <span className="text-blue-700 underline text-center block font-medium">
              Open Issue in Github{' '}
            </span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default IssueBox;
