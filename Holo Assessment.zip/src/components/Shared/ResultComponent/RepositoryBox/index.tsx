import Link from 'next/link';
import dateFormat from 'dateformat';
import UserBox from '../UserBox';

type Props = {
  repoName: string;
  repoAuthor?: string;
  repoAuthorAvatar?: string;
  repoAuthorUrl?: string;
  repoStars: number;
  repoUrl: string;
  repoDescription: string;
  repoCreatedDate: string;
};
const RepositoryBox = ({
  repoName,
  repoAuthor,
  repoAuthorAvatar,
  repoAuthorUrl,
  repoStars,
  repoUrl,
  repoDescription,
  repoCreatedDate
}: Props) => {
  return (
    <div className="py-3 h-full">
      <div className="flex flex-col gap-3 justify-between h-full ">
        <Link href={repoUrl} passHref>
          <a>
            <h3 className="font-bold text-lg capitalize hover:text-blue-700 w-full overflow-hidden">
              {repoName}
            </h3>
          </a>
        </Link>
        <p className="overflow-hidden truncate block ">{repoDescription}</p>
        <div className="flex gap-3 justify-between">
          <p className="w-2/3">
            <span className="block font-bold">Created Date : </span>
            {dateFormat(repoCreatedDate, 'mediumDate')}
          </p>
          <p className="w-1/3">
            <span className="block font-bold">Rate : </span> {repoStars}
          </p>
        </div>

        <UserBox
          showBorder
          userName={repoAuthor}
          userAvatar={repoAuthorAvatar}
          userUrl={repoAuthorUrl}
        />

        <Link href={repoUrl} passHref>
          <a target="_blank">
            <span className="text-blue-700 underline text-center block font-medium">
              Open Repository in Github{' '}
            </span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default RepositoryBox;
