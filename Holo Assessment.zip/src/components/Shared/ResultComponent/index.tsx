import { useSelector } from 'react-redux';
import { InitState } from 'types/InitReducer';
import ErrorMessage from '../ErrorMessage';
import LoaderIcon from '../Icons/LoaderIcon';
import IssueBox from './IssueBox';
import RepositoryBox from './RepositoryBox';
import UserBox from './UserBox';

type Props = {
  searchType: string;
};
const ResultComponent = ({ searchType }: Props) => {
  const state = useSelector((state: InitState) => state);

  return (
    <div className="flex gap-4  flex-col mb-4   w-full  max-h-[70vh] overflow-auto">
      {state.dataError && <ErrorMessage message={state.dataError} />}
      {!state.dataLoaded && <LoaderIcon />}
      <div className="flex gap-[20px] flex-wrap w-full p-2 ">
        {state.searchValue.length >= 3 &&
          !state.dataError &&
          state.data.map(item => (
            <div
              key={item.id}
              className=" w-full sm:w-[calc(49.999%_-_10px)] md:w-[calc(33.33%_-_15px)] border-[2px] border-gray-400 px-3 rounded-md"
            >
              {searchType == 'repositories' && (
                <RepositoryBox
                  repoName={item.name}
                  repoAuthor={item.owner?.login}
                  repoAuthorAvatar={item.owner?.avatar_url}
                  repoAuthorUrl={item.owner?.html_url}
                  repoStars={item.stargazers_count}
                  repoUrl={item.html_url}
                  repoDescription={item.description}
                  repoCreatedDate={item.created_at}
                />
              )}
              {searchType == 'users' && (
                <UserBox
                  userName={item.login}
                  userAvatar={item.avatar_url}
                  userUrl={item.html_url}
                />
              )}

              {searchType == 'issues' && (
                <IssueBox
                  repoUrl={item.html_url}
                  issueUrl={item.url}
                  issueTitle={item.title}
                  issueAuthor={item.user?.login}
                  issueAuthorAvatar={item.user?.avatar_url}
                  issueAuthorUrl={item.user?.html_url}
                  issueCreatedDate={item.created_at}
                  issueState={item.state}
                  issueBody={item.body}
                />
              )}
            </div>
          ))}
      </div>
    </div>
  );
};

export default ResultComponent;
