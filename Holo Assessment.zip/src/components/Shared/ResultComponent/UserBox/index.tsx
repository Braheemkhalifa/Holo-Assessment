import Image from 'next/image';
import Link from 'next/link';

type Props = {
  userName?: string;
  userAvatar?: string;
  userUrl?: string;
  showBorder?: boolean;
};
const UserBox = ({ userName, userAvatar, userUrl, showBorder }: Props) => {
  return (
    <div
      className={`flex   border-gray-500 py-3 gap-3 items-center
    ${showBorder && 'border-t-[1px]'}
    
    `}
    >
      <div className="w-[29px] h-[29px] block relative rounded-[50%] overflow-hidden">
        {userAvatar && <Image src={userAvatar} alt={userName} layout="fill" />}
      </div>
      <div className=" w-[calc(100%_-_40px)] ">
        <Link href={userUrl || ''} passHref>
          <a>
            <h6 className="font-bold text-sm capitalize hover:text-blue-700 leading-tight w-full overflow-hidden truncate block">
              {userName}
            </h6>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default UserBox;
