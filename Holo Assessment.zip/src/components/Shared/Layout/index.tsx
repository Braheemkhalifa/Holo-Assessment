import { ReactNode } from 'react';

type Props = {
  children: ReactNode;
};
const Layout = ({ children }: Props) => {
  return (
    <div className="flex flex-row justify-center align-middle items-center h-[100vh] w-full ">
      <div className=" w-11/12 lg:w-2/3 h-auto">{children}</div>
    </div>
  );
};

export default Layout;
