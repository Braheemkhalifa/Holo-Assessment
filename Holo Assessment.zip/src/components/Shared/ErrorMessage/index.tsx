type Props = {
  message: string;
};
const ErrorMessage = ({ message }: Props) => {
  return <div className="bg-red-100 p-3 text-red-500 ">{message}</div>;
};

export default ErrorMessage;
