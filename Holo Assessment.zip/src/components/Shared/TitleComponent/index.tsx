import { ReactNode } from 'react';

type Props = {
  icon: ReactNode;
  title: string;
  subTitle?: string;
};
const TitleComponent = ({ icon, title, subTitle }: Props) => {
  return (
    <div className="flex   gap-4  w-full">
      <div className=" w-12">{icon}</div>
      <div className=" ">
        <h3 className="font-bold text-xl capitalize">{title}</h3>
        {subTitle && <p className="font-normal  text-lg text-gray-400 leading-5">{subTitle}</p>}
      </div>
    </div>
  );
};

export default TitleComponent;
