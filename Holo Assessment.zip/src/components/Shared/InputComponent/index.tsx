import { getOrders } from 'apis/DataApi';
import { useDispatch, useSelector } from 'react-redux';
import { UpdateReduxData } from 'redux/reducer';
import { InitState } from 'types/InitReducer';

const InputComponent = () => {
  const dispatch = useDispatch();
  const state = useSelector((state: InitState) => state);

  const onChangeHandler = e => {
    dispatch(UpdateReduxData('searchValue', e.target.value));

    if (e.target.value.length >= 3) {
      dispatch(UpdateReduxData('dataLoaded', false));
      getOrders(state.searchType, e.target.value)
        .then(res => {
          dispatch(UpdateReduxData('data', res.data.items));
          dispatch(UpdateReduxData('dataLoaded', true));
          dispatch(UpdateReduxData('dataError', null));
        })
        .catch(err => {
          dispatch(UpdateReduxData('dataError', err.message));
          dispatch(UpdateReduxData('dataLoaded', true));
        });
    }
  };

  return (
    <input
      className="border-gray-400 border-[1px] w-full h-[45px] py-2 px-4 focus:outline-gray-400 rounded-md	 "
      placeholder="Start typing to search ..."
      onChange={onChangeHandler}
    />
  );
};

export default InputComponent;
