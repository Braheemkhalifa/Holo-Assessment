import { getOrders } from 'apis/DataApi';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { UpdateReduxData } from 'redux/reducer';
import { InitState } from 'types/InitReducer';
import DropDownArrow from '../Icons/DropDownArrow';

type Props = {
  options: { name: string }[];
  selected: string;
};

const DropdownComponent = ({ options, selected }: Props) => {
  const [dropDownActive, setDropDownActive] = useState(false);

  const dispatch = useDispatch();
  const state = useSelector((state: InitState) => state);

  const handleMenuDropDown = () => {
    setDropDownActive(!dropDownActive);
  };

  const handleOnSelect = value => {
    dispatch(UpdateReduxData('searchType', value));

    if (state.searchValue.length >= 3) {
      dispatch(UpdateReduxData('dataLoaded', false));

      getOrders(value, state.searchValue)
        .then(res => {
          dispatch(UpdateReduxData('data', res.data.items));
          dispatch(UpdateReduxData('dataLoaded', true));
          dispatch(UpdateReduxData('dataError', null));
        })
        .catch(err => {
          dispatch(UpdateReduxData('dataError', err.message));
          dispatch(UpdateReduxData('dataLoaded', true));
        });
    }

    setDropDownActive(false);
  };

  return (
    <div className="relative w-full">
      <button
        type="button"
        onClick={handleMenuDropDown}
        className=" w-full h-[45px] py-2 px-3 	 flex justify-between capitalize items-center font-normal  text-lg text-gray-100 rounded-md border border-gray-400 bg-white 	  hover:bg-gray-50 focus:outline-none focus:border-gray-400 "
      >
        <span className=" w-full  h-full text-left text-gray-400  overflow-hidden">{selected}</span>
        <DropDownArrow />
      </button>

      {dropDownActive && (
        <div
          className="absolute right-0 left-0 z-10 mt-2 w-full origin-top-right  rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
          role="menu"
          aria-orientation="vertical"
          aria-labelledby="menu-button"
        >
          <div role="none">
            {options.map(option => (
              <div
                key={option.name}
                onClick={() => handleOnSelect(option.name)}
                className="text-gray-700 block px-4 py-2 text-sm capitalize cursor-pointer rounded-md hover:bg-black hover:text-white"
              >
                {option.name}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default DropdownComponent;
