import DropdownComponent from 'components/Shared/DropdownComponent';
import GithubIcon from 'components/Shared/Icons/GithubIcon';
import InputComponent from 'components/Shared/InputComponent';
import ResultComponent from 'components/Shared/ResultComponent';
import TitleComponent from 'components/Shared/TitleComponent';
import { useSelector } from 'react-redux';
import { InitState } from 'types/InitReducer';

const options = [{ name: 'users' }, { name: 'repositories' }, { name: 'issues' }];

const Home = () => {
  const state = useSelector((state: InitState) => state);
  return (
    <div className="flex flex-col gap-4">
      <TitleComponent
        icon={<GithubIcon />}
        title="GitHub Searcher"
        subTitle="Search users or repositories below"
      />
      <div className="flex   gap-4  mb-4   w-full max-w-xl ">
        <div className=" w-2/3 md:w-3/4">
          <InputComponent />
        </div>
        <div className="w-1/3 md:w-1/4 ">
          <DropdownComponent options={options} selected={state.searchType} />
        </div>
      </div>
      {state.data && <ResultComponent searchType={state.searchType} />}
    </div>
  );
};

export default Home;
