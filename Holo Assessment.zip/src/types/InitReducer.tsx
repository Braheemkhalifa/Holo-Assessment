export type InitState = {
  searchType: string;
  searchValue: string;
  dataError: string;
  dataLoaded: boolean;
  data: {
    id: string;
    name: string;
    title?: string;
    owner?: {
      login?: string;
      avatar_url?: string;
      html_url?: string;
    };
    user?: {
      login?: string;
      avatar_url?: string;
      html_url?: string;
    };
    state?: string;
    body?: string;
    url?: string;
    login?: string;
    avatar_url?: string;
    repoAuthor?: string;
    repoAuthorAvatar?: string;
    repoAuthorUrl?: string;
    stargazers_count?: number;
    html_url?: string;
    description?: string;
    created_at?: string;
  }[];
};
