import Home from 'pages/home';

export default Home;
