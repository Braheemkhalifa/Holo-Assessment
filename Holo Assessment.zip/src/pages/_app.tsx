import '../styles/globals.scss';
import Layout from 'components/Shared/Layout';
import Head from 'next/head';
import store, { persistor } from '../redux/configureStore';

import { PersistGate } from 'redux-persist/integration/react';
import { Provider } from 'react-redux';

function MyApp({ Component, pageProps }) {
  return (
    <Layout>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <Head>
            <title>HOLO | GitHub Searcher</title>
            <meta name="viewport" content="initial-scale=1.0, width=device-width" />
          </Head>
          <Component {...pageProps} />
        </PersistGate>
      </Provider>
    </Layout>
  );
}

export default MyApp;
