import Home from 'components/Home';

const index = () => <Home />;

export default index;
